// The North Face (www.thenorthface.com, Vue/Nuxt storefront). Every selector and URL for this site lives here.
// Product + listing selectors verified against the live site on 2026-11-25.
// Checkout selectors are UNVERIFIED (the site's bot protection blocked add-to-cart in testing, so checkout
// couldn't be reached). Filling falls back to standard autocomplete attributes, which most checkouts use.
// See README → "Updating selectors" for the 2-minute DevTools routine to confirm them.
(function (root) {
  'use strict';
  const DA = (root.DA = root.DA || {});
  DA.config = DA.config || {};

  DA.config.tnf = {
    id: 'tnf',
    name: 'The North Face',
    origin: 'https://www.thenorthface.com',

    // Keyword mode searches these listing pages (override per watchlist item with "Category URL").
    defaultCategories: [
      '/en-us/c/mens/mens-featured/mens-new-arrivals-226102',
      '/en-us/c/womens/womens-featured/womens-new-arrivals-226114',
      '/en-us/c/shop-all/footwear-new-arrivals-829848',
      '/en-us/c/bags-and-gear/featured/new-arrivals-226139'
    ],
    cartPath: '/en-us/cart',

    selectors: {
      // listing
      productCard: '[data-test-id="product-card"]',
      productCardTitle: 'a[data-test-id="product-card-title"]',
      // product page
      productName: '[data-test-id="product-name"]',
      colorButton: 'button[data-test-id="vf-color-picker"]',  // color name is in a .sr-only span; aria-current="true" = selected
      sizeLabel: 'label[data-test-id="vf-size-picker"]',      // wraps input[type=radio][name="Size"]
      sizeAvailable: '[data-test-id="vf-size-picker-label-available"]',
      addToCart: '#pdp-add-to-cart',
      cartLink: 'a[href$="/cart"]',                            // text like "Cart - 2 items"
      // cart / checkout (UNVERIFIED)
      cartCheckoutButton: ['[data-test-id*="checkout" i]', 'a[href*="/checkout"]'],
      payButton: ['[data-test-id*="place-order" i]', 'button[type="submit"]'],
      payButtonText: /place order|submit order|pay now|complete order/i,
      checkoutButtonText: /^\s*(secure\s+)?checkout\s*$/i,
      cardNumberFrame: 'iframe[title*="card number" i]'
    },

    checkoutExclude: '[aria-hidden="true"]',
    // Selectors are best guesses; autocomplete attributes are the real safety net.
    checkoutFields: [
      { key: 'country', selectors: ['select[name*="country" i]'], waitAfterMs: 300, optional: true },
      { key: 'email', selectors: ['input[type="email"]', 'input[name*="email" i]'] },
      { key: 'firstName', selectors: ['input[name="firstName"]', 'input[name*="first" i]'] },
      { key: 'lastName', selectors: ['input[name="lastName"]', 'input[name*="last" i]'] },
      { key: 'address1', selectors: ['input[name="addressLine1"]', 'input[name="address1"]'], waitAfterMs: 150 },
      { key: 'address2', selectors: ['input[name="addressLine2"]', 'input[name="address2"]'], optional: true },
      { key: 'city', selectors: ['input[name="city"]'] },
      { key: 'state', selectors: ['select[name="province"]', 'select[name="state"]', 'select[name*="state" i]'] },
      { key: 'zip', selectors: ['input[name="postalCode"]', 'input[name*="zip" i]', 'input[name*="postal" i]'] },
      { key: 'phone', selectors: ['input[type="tel"]', 'input[name*="phone" i]'] }
    ],

    blockers: {
      queueUrl: /\/(queue|waiting-?room)\b/i,
      queueText: /you('|’)re in line|waiting room|in the queue|high demand/i,
      captchaSelectors: [
        'iframe[src*="recaptcha"][src*="bframe"]',   // the visible challenge, not the always-present badge
        'iframe[src*="hcaptcha.com"]',
        'iframe[src*="captcha-delivery"]',
        'iframe[title*="challenge" i]'
      ]
    }
  };
})(typeof self !== 'undefined' ? self : globalThis);
