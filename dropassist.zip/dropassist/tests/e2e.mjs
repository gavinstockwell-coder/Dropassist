// End-to-end test: loads the real extension in Chrome and runs it against local copies of the
// Supreme / TNF pages (same DOM structure and endpoints as the live sites, captured 2026-11-25).
// Run: node tests/e2e.mjs   (needs Chrome/Chromium + playwright; not shipped to users)
import { createRequire } from 'node:module';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const EXT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CHROME = process.env.CHROME_PATH || '/usr/bin/google-chrome';

const results = [];
const check = (name, cond, extra = '') => { results.push({ name, ok: !!cond, extra }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------- Supreme fixtures ----------------
const sup = { dropped: false, cart: [], addCalls: [], addFails: 0, captcha: false };
const supProduct = (id, title, color, sizes, handle) => ({
  id, title, handle, url: `/products/${handle}`, product_type: 'sweatshirts', color, style: 'S1', is_new: true, available: true,
  variants: Object.entries(sizes).map(([t, a], i) => ({ id: id * 10 + i, title: t, public_title: t, available: a }))
});
function supListing() {
  const products = [
    supProduct(1001, 'Box Logo Tee', 'White', { Medium: true, Large: true }, 'tee-white'),
    supProduct(1002, 'Box Logo Hooded Sweatshirt', 'Ash Grey', { Medium: true, Large: true }, 'old-hood-grey') // old stock that matches keywords
  ];
  if (sup.dropped) {
    products.unshift(supProduct(2001, 'Box Logo Hooded Sweatshirt', 'Black', { Small: true, Medium: true, Large: false, XLarge: true }, 'bogo-black'));
    products.unshift(supProduct(2002, 'Box Logo Hooded Sweatshirt', 'Red', { Medium: true, Large: true }, 'bogo-red'));
  }
  return products;
}
const page = (title, body) => `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>body{font-family:sans-serif;padding:20px} input,select{display:block;margin:6px 0;width:300px;height:28px} .off{position:absolute;left:-9999px;width:200px;height:20px}</style></head><body>${body}</body></html>`;

function supListingHtml() {
  const data = { allProductsCount: supListing().length, products: supListing() };
  return page('Shop - Supreme', `<h1>new</h1><ul data-testid="product-list">${supListing().map((p) => `<li><a href="${p.url}?new=1">${p.title}</a></li>`).join('')}</ul>
<script type="application/json" id="products-json">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>`);
}
function supProductHtml(handle) {
  const p = supListing().find((x) => x.handle === handle);
  if (!p) return page('Not found', '<h1>404</h1>');
  const opts = p.variants.filter((v) => v.available).map((v) => `<option value="${v.id}">${v.title}</option>`).join('');
  return page(p.title, `<div data-testid="product-page"><h1>${p.title} – ${p.color}</h1>
<select aria-label="size" name="size" data-testid="size-dropdown">${opts}</select>
<button data-testid="add-to-cart-button">add to cart</button><div id="msg"></div></div>
<script>
document.querySelector('[data-testid=add-to-cart-button]').addEventListener('click', async () => {
  const id = document.querySelector('[data-testid=size-dropdown]').value;
  const r = await fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({items:[{id:Number(id),quantity:1}]})});
  if (r.ok) document.getElementById('msg').innerHTML = '<p data-testid="product-in-cart-message">in cart</p>';
});
</script>`);
}
function supCheckoutHtml() {
  const zone = ['AL:Alabama', 'CA:California', 'NY:New York', 'TX:Texas'].map((s) => { const [v, t] = s.split(':'); return `<option value="${v}">${t}</option>`; }).join('');
  return page('Checkout - Supreme', `<form>
<input id="email" name="email" autocomplete="shipping email" placeholder="Email">
<select name="countryCode" autocomplete="shipping country-name"><option value="CA">Canada</option><option value="US" selected>United States</option></select>
<input name="firstName" autocomplete="shipping given-name" placeholder="First name">
<input name="lastName" autocomplete="shipping family-name" placeholder="Last name">
<input id="shipping-address1" name="address1" autocomplete="shipping address-line1" placeholder="Address">
<input name="address2" autocomplete="shipping address-line2">
<input name="city" autocomplete="shipping address-level2">
<select name="zone" autocomplete="shipping address-level1">${zone}</select>
<input name="postalCode" autocomplete="shipping postal-code">
<input name="phone" type="tel" autocomplete="shipping tel-national">
<input id="autofill_firstName" class="off" name="firstName" autocomplete="shipping given-name" aria-label="First name">
<input id="autofill_address1" class="off" name="address1" autocomplete="shipping address-line1">
<iframe title="Card number" src="https://checkout.pci.shopifyinc.com/build/c07a878/number-ltr.html?identifier=&locationURL=" style="width:300px;height:44px"></iframe>
<iframe title="Expiration date (MM / YY)" src="https://checkout.pci.shopifyinc.com/build/c07a878/expiry-ltr.html?identifier=" style="width:300px;height:44px"></iframe>
<iframe title="Security code" src="https://checkout.pci.shopifyinc.com/build/c07a878/verification_value-ltr.html?identifier=" style="width:300px;height:44px"></iframe>
<iframe title="Name on card" src="https://checkout.pci.shopifyinc.com/build/c07a878/name-ltr.html?identifier=" style="width:300px;height:44px"></iframe>
<button id="checkout-pay-button" type="submit" aria-label="process payment">process payment</button>
</form>${sup.captcha ? '<iframe id="cap" src="about:blank#https://newassets.hcaptcha.com/captcha" style="width:400px;height:500px"></iframe>' : ''}`);
}

function pciFrameHtml(current) {
  const fields = [['number', 'cc-number'], ['name', 'cc-name'], ['expiry_month', 'cc-exp-month'], ['expiry_year', 'cc-exp-year'], ['expiry', 'cc-exp'], ['verification_value', 'cc-csc'], ['issue_date', 'off']];
  return `<!doctype html><html><body style="margin:0"><form>${fields.map(([n, ac]) =>
    `<div style="${n === current ? '' : 'display:none'}"><input id="${n}" name="${n}" autocomplete="${ac}" type="text" style="width:280px;height:30px"></div>`).join('')}</form></body></html>`;
}
async function routePci(ctx) {
  await ctx.route('https://checkout.pci.shopifyinc.com/**', (route) => {
    const m = new URL(route.request().url()).pathname.match(/\/(\w+)-ltr\.html/);
    return route.fulfill({ status: 200, contentType: 'text/html', body: pciFrameHtml(m ? m[1] : 'number') });
  });
}
async function routeSupreme(ctx) {
  await ctx.route('https://us.supreme.com/**', async (route) => {
    const req = route.request();
    const u = new URL(req.url());
    const p = u.pathname;
    const json = (obj, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(obj) });
    const html = (body, status = 200) => route.fulfill({ status, contentType: 'text/html; charset=utf-8', body });
    if (p === '/collections/new') return html(supListingHtml());
    if (p.startsWith('/products/')) return html(supProductHtml(p.split('/')[2]));
    if (p === '/cart/add.js') {
      const body = JSON.parse(req.postData() || '{}');
      sup.addCalls.push(body);
      if (sup.addFails > 0) { sup.addFails--; return json({ status: 503, message: 'busy' }, 503); }
      const id = body.items[0].id;
      const v = supListing().flatMap((x) => x.variants).find((x) => x.id === id);
      if (!v || !v.available) return json({ status: 422, description: 'sold out' }, 422);
      sup.cart.push(id);
      return json({ items: [{ id }] });
    }
    if (p === '/cart.js') return json({ item_count: sup.cart.length, items: sup.cart.map((id) => ({ id })) });
    if (p === '/cart/clear.js') { sup.cart = []; return json({ item_count: 0 }); }
    if (p === '/checkout') return route.fulfill({ status: 302, headers: { location: 'https://us.supreme.com/checkouts/cn/tok123/en-us' } });
    if (p.startsWith('/checkouts/')) return html(supCheckoutHtml());
    return html(page('Supreme', '<h1>home</h1>'));
  });
}

// ---------------- TNF fixtures ----------------
const tnf = { cartCount: 0 };
function tnfProductHtml() {
  const sizes = [['S', true], ['M', true], ['L', false]].map(([v, a]) =>
    `<label class="relative" data-test-id="vf-size-picker"><input class="peer sr-only" type="radio" value="${v}" name="Size">
     <span data-test-id="vf-size-picker-label-${a ? 'available' : 'unavailable'}"><span data-test-id="vf-size-picker-text">${v}</span></span></label>`).join('');
  const colors = [['TNF Black', 'true'], ['Summit Gold', 'false']].map(([n, cur]) =>
    `<button data-test-id="vf-color-picker" type="button" aria-current="${cur}" style="width:40px;height:26px"><span unavailable="false"><span class="sr-only">${n}</span></span></button>`).join('');
  return page('Men’s 1996 Retro Nuptse Jacket | The North Face', `<header><a href="/en-us/cart" data-test-id="base-link" id="cartlink">Cart - ${tnf.cartCount} items</a></header>
<h1 data-test-id="product-name">Men’s 1996 Retro Nuptse Jacket</h1>
<section data-test-id="color-groups">${colors}</section>
<section data-test-id="size-groups">${sizes}</section>
<button data-test-id="vf-button" type="submit" id="pdp-add-to-cart">Add to Cart</button>
<script>
  // Simulates the bot protection: the automated click does nothing. The test "is the user" and adds it later.
  window.__userAdds = () => { document.getElementById('cartlink').textContent = 'Cart - 1 items'; };
</script>`);
}
function tnfCartHtml() {
  return page('Cart | The North Face', `<a href="/en-us/cart">Cart - ${tnf.cartCount} items</a><h1>Cart</h1>
<button data-test-id="cart-checkout-button" onclick="location.href='/en-us/checkout'">Checkout</button>`);
}
function tnfCheckoutHtml() {
  return page('Checkout | The North Face', `<h1>Shipping</h1>
<input type="email" name="email" autocomplete="email">
<input name="firstName" autocomplete="given-name">
<input name="lastName" autocomplete="family-name">
<input name="addressLine1" autocomplete="address-line1">
<input name="addressLine2" autocomplete="address-line2">
<input name="city" autocomplete="address-level2">
<select name="province" autocomplete="address-level1"><option value="">State</option><option value="CA">California</option><option value="TX">Texas</option></select>
<input name="postalCode" autocomplete="postal-code">
<input name="phone" type="tel" autocomplete="tel">
<button type="submit" data-test-id="place-order">Place Order</button>`);
}
async function routeTnf(ctx) {
  await ctx.route('https://www.thenorthface.com/**', async (route) => {
    const p = new URL(route.request().url()).pathname;
    const html = (body) => route.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body });
    if (p.includes('/p/')) return html(tnfProductHtml());
    if (p === '/en-us/cart') return html(tnfCartHtml());
    if (p === '/en-us/checkout') return html(tnfCheckoutHtml());
    return html(page('The North Face', '<h1>home</h1>'));
  });
}

// ---------------- harness ----------------
const PROFILE = { email: 'gavin@example.com', firstName: 'Gavin', lastName: 'Test', address1: '123 Main St', address2: 'Apt 4', city: 'Houston', state: 'TX', zip: '77002', phone: '(713) 555-0100', country: 'US' };

async function main() {
  const userDir = fs.mkdtempSync(path.join(os.tmpdir(), 'da-e2e-'));
  const ctx = await chromium.launchPersistentContext(userDir, {
    executablePath: CHROME, headless: true,
    args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-first-run', '--autoplay-policy=no-user-gesture-required']
  });
  await routeSupreme(ctx);
  await routePci(ctx);
  await routeTnf(ctx);
  let sw = ctx.serviceWorkers()[0];
  if (!sw) sw = await ctx.waitForEvent('serviceworker', { timeout: 15000 });
  check('extension service worker started', !!sw, sw && sw.url());
  await sleep(800); // onInstalled defaults
  for (const p of ctx.pages()) if (p.url().startsWith('chrome-extension://')) await p.close();

  const getRun = () => sw.evaluate(() => chrome.storage.local.get('run').then((x) => x.run));
  const getLog = () => sw.evaluate(() => chrome.storage.local.get('log').then((x) => (x.log || []).map((e) => `${e.lvl} ${e.msg}`)));
  const waitPhase = async (phases, timeout) => {
    const end = Date.now() + timeout;
    while (Date.now() < end) { const r = await getRun(); if (r && phases.includes(r.phase)) return r; await sleep(250); }
    return getRun();
  };
  const runTabPage = async () => {
    const r = await getRun();
    for (const p of ctx.pages()) {
      const id = await sw.evaluate((u) => chrome.tabs.query({}).then((ts) => (ts.find((t) => t.url === u) || {}).id), p.url());
      if (id === r.tabId) return p;
    }
    return ctx.pages()[ctx.pages().length - 1];
  };
  const setup = (settings, watchlist) => sw.evaluate(async ([s, w, prof]) => {
    const st = await chrome.storage.local.get('profiles');
    const card = (st.profiles && st.profiles[0] && st.profiles[0].card) || null;
    await chrome.storage.local.set({ settings: Object.assign({}, self.DA.defaults.settings, s), watchlist: w, profiles: [{ id: 'p1', name: 'Main', shipping: prof, card }], activeProfileId: 'p1', log: [], run: { active: false, phase: 'idle' } });
  }, [settings, watchlist, PROFILE]);
  const cardVals = async (pg) => {
    const out = {};
    for (const f of pg.frames()) {
      if (!f.url().includes('pci.shopifyinc.com')) continue;
      const kind = (f.url().match(/\/(\w+)-ltr/) || [])[1];
      const sel = { number: '#number', expiry: '#expiry', verification_value: '#verification_value', name: '#name' }[kind];
      if (sel) out[kind] = await f.$eval(sel, (e) => e.value).catch(() => '?');
    }
    return out;
  };

  // ---- 0. Profile card vault: create, save card, check storage has no plaintext ----
  await setup({}, []);
  const vs = await sw.evaluate(async () => {
    const create = await self.handle({ type: 'vaultCreate', pass: 'drop-day-123' }, {});
    const saved = await self.handle({ type: 'saveCard', profileId: 'p1', card: { number: '4242 4242 4242 4242', exp: '08/29', cvv: '123', name: '' } }, {});
    const raw = JSON.stringify(await chrome.storage.local.get(null));
    return { unlocked: create.unlocked, saved: saved.card, plaintext: raw.includes('4242424242424242') || raw.includes('"123"') };
  });
  check('V1: vault created, card saved encrypted (no plaintext on disk)', vs.unlocked && vs.saved.last4 === '4242' && !vs.plaintext, JSON.stringify(vs));

  // ---- 1. Supreme, start now, direct cart add, priority + fill ----
  sup.dropped = false; sup.cart = []; sup.addCalls = [];
  await setup({ pollMs: 1000, addMethod: 'direct', sound: false }, [
    { id: 'w1', enabled: true, site: 'supreme', label: 'BOGO', include: ['box logo', 'hooded'], exclude: ['tee'], colors: ['black', 'red'], sizes: ['L', 'M'], url: '', category: '', dropAt: null }
  ]);
  // Old grey hoodie matches keywords but not colors → must be skipped; drop black + red at ~3s.
  await sw.evaluate(() => self.arm({ mode: 'now', site: 'supreme' }));
  setTimeout(() => { sup.dropped = true; }, 3000);
  let r = await waitPhase(['ready', 'stopped'], 25000);
  check('S1: reached checkout ready', r.phase === 'ready', `phase=${r.phase} note=${r.note}`);
  check('S1: added Black / Medium (L sold out → next size, black beats red)', sup.addCalls.length >= 1 && sup.addCalls[0].items[0].id === 20011, JSON.stringify(sup.addCalls));
  let pg = await runTabPage();
  const vals = await pg.evaluate(() => {
    const q = (s) => document.querySelector(s);
    return { email: q('#email').value, first: q('input[name=firstName]:not([id^=autofill_])').value, last: q('input[name=lastName]').value, a1: q('#shipping-address1').value, a2: q('input[name=address2]').value, city: q('input[name=city]').value, zone: q('select[name=zone]').value, zip: q('input[name=postalCode]').value, phone: q('input[name=phone]').value, hiddenFirst: q('#autofill_firstName').value, hl: !!q('#checkout-pay-button[data-dropassist-hl]'), url: location.pathname };
  });
  check('S1: checkout fields filled', vals.email === PROFILE.email && vals.first === 'Gavin' && vals.last === 'Test' && vals.a1 === '123 Main St' && vals.a2 === 'Apt 4' && vals.city === 'Houston' && vals.zone === 'TX' && vals.zip === '77002' && vals.phone === '7135550100', JSON.stringify(vals));
  check('S1: hidden Shopify autofill_* inputs left alone', vals.hiddenFirst === '');
  check('S1: pay button highlighted, not clicked', vals.hl && vals.url.startsWith('/checkouts/'));
  await sleep(1500);
  const cv = await cardVals(pg);
  check('S1: card filled into Shopify secure fields from the vault', cv.number === '4242424242424242' && cv.expiry === '08 / 29' && cv.verification_value === '123' && cv.name === 'Gavin Test', JSON.stringify(cv));
  r = await getRun();
  check('S1: timings recorded', r.marks && r.marks.match && r.marks.atc && r.marks.ready, JSON.stringify(r.marks));
  const log1 = await getLog();
  check('S1: log explains skipped old color', log1.some((l) => /Ash Grey: color "Ash Grey" not in your list/.test(l)), '');
  await sw.evaluate(() => self.stopRun('test done'));

  // ---- 2. Supreme dry run, direct add fails (503) → product-page fallback ----
  sup.dropped = true; sup.cart = []; sup.addCalls = []; sup.addFails = 1;
  await sw.evaluate(() => self.handle({ type: 'vaultLock' }, {}));
  await setup({ pollMs: 1000, addMethod: 'direct', sound: false }, []);
  await sw.evaluate(() => self.arm({ mode: 'dry', site: 'supreme', keyword: 'tee' }));
  r = await waitPhase(['ready', 'stopped'], 25000);
  check('S2: dry run reached checkout via product-page fallback', r.phase === 'ready' && r.dryRun, `phase=${r.phase} note=${r.note}`);
  check('S2: first direct add failed, page click added it', sup.addCalls.length === 2 && sup.cart.length === 1, JSON.stringify(sup.addCalls));
  pg = await runTabPage();
  const dryHl = await pg.evaluate(() => !!document.querySelector('[data-dropassist-hl]'));
  check('S2: dry run does not highlight pay button', !dryHl);
  await sleep(1200);
  const cv2 = await cardVals(pg);
  check('S2: locked vault → card left empty', !cv2.number && !cv2.verification_value, JSON.stringify(cv2));
  const unl = await sw.evaluate(() => self.handle({ type: 'vaultUnlock', pass: 'nope' }, {}).then(() => 'ok', (e) => e.message));
  check('S2: wrong passphrase rejected', unl === 'Wrong passphrase', unl);
  await sw.evaluate(() => self.handle({ type: 'vaultUnlock', pass: 'drop-day-123' }, {}));
  await sw.evaluate(() => self.stopRun('test done'));

  // ---- 3. Supreme armed run with pre-drop baseline (old-stock filter) ----
  sup.dropped = false; sup.cart = []; sup.addCalls = [];
  const dropAt = Date.now() + 16000;
  await setup({ pollMs: 1000, leadSec: 3, runMin: 2, onlyNew: true, sound: false }, [
    { id: 'w3', enabled: true, site: 'supreme', label: 'any hooded', include: ['hooded'], exclude: [], colors: [], sizes: ['M'], url: '', category: '', dropAt }
  ]);
  await sw.evaluate(() => self.arm({ mode: 'scheduled' }));
  setTimeout(() => { sup.dropped = true; }, dropAt - Date.now() + 500);
  r = await waitPhase(['monitoring'], 20000);
  check('S3: baseline captured before drop', Array.isArray(r.baseline) && r.baseline.includes('1002'), JSON.stringify(r.baseline));
  check('S3: monitoring started before drop time', r.marks.monitor && r.marks.monitor < dropAt, `${r.marks.monitor - dropAt} ms vs drop`);
  r = await waitPhase(['ready', 'stopped'], 20000);
  const firstAdd = sup.addCalls[0] && sup.addCalls[0].items[0].id;
  check('S3: ignored old grey hoodie, bought a new one', r.phase === 'ready' && [20011, 20020].includes(firstAdd), `added=${firstAdd} phase=${r.phase}`);
  await sw.evaluate(() => self.stopRun('test done'));

  // ---- 4. TNF by URL: automated click rejected → manual handoff → cart → checkout fill ----
  tnf.cartCount = 0;
  await setup({ pollMs: 1000, sound: false }, [
    { id: 't1', enabled: true, site: 'tnf', label: 'Nuptse', include: [], exclude: [], colors: ['black'], sizes: ['L', 'M'], url: 'https://www.thenorthface.com/en-us/p/mens/x/mens-1996-retro-nuptse-jacket-NF0A3C8D?color=JK3', category: '', dropAt: null }
  ]);
  await sw.evaluate(() => self.arm({ mode: 'now', site: 'tnf' }));
  r = await waitPhase(['manual', 'ready', 'stopped'], 25000);
  check('T1: hands over when the click is rejected', r.phase === 'manual', `phase=${r.phase} note=${r.note}`);
  pg = await runTabPage();
  const tnfSel = await pg.evaluate(() => ({ size: (document.querySelector('input[name=Size]:checked') || {}).value, hl: !!document.querySelector('#pdp-add-to-cart[data-dropassist-hl]') }));
  check('T1: picked M (L sold out) and highlighted Add to Cart', tnfSel.size === 'M' && tnfSel.hl, JSON.stringify(tnfSel));
  tnf.cartCount = 1;
  await pg.evaluate(() => window.__userAdds());
  r = await waitPhase(['ready', 'stopped'], 20000);
  check('T1: continued to checkout after user added', r.phase === 'ready', `phase=${r.phase} note=${r.note}`);
  pg = await runTabPage();
  const tv = await pg.evaluate(() => ({ email: document.querySelector('[name=email]').value, a1: document.querySelector('[name=addressLine1]').value, st: document.querySelector('[name=province]').value, zip: document.querySelector('[name=postalCode]').value, hl: !!document.querySelector('[data-test-id=place-order][data-dropassist-hl]') }));
  check('T1: TNF checkout filled via autocomplete + highlighted Place Order', tv.email === PROFILE.email && tv.a1 === '123 Main St' && tv.st === 'TX' && tv.zip === '77002' && tv.hl, JSON.stringify(tv));
  await sw.evaluate(() => self.stopRun('test done'));

  // ---- 5. CAPTCHA on Supreme checkout: pause, then resume once solved ----
  sup.dropped = true; sup.cart = []; sup.addCalls = []; sup.captcha = true;
  await setup({ pollMs: 1000, sound: false }, [
    { id: 'w5', enabled: true, site: 'supreme', include: ['tee'], exclude: [], colors: [], sizes: [], url: '', category: '', dropAt: null }
  ]);
  await sw.evaluate(() => self.arm({ mode: 'now', site: 'supreme' }));
  const capEnd = Date.now() + 20000;
  while (Date.now() < capEnd && !((await getRun()).blocked)) await sleep(250);
  r = await getRun();
  check('C1: CAPTCHA detected, run paused before filling', r.blocked === 'captcha' && r.phase === 'checkout', `blocked=${r.blocked} phase=${r.phase}`);
  pg = await runTabPage();
  await pg.evaluate(() => document.getElementById('cap').remove());
  r = await waitPhase(['ready'], 20000);
  check('C1: resumed after CAPTCHA cleared and finished', r.phase === 'ready' && !r.blocked, `phase=${r.phase}`);
  sup.captcha = false;
  await sw.evaluate(() => self.stopRun('test done'));

  const errs = (await getLog()).filter((l) => l.startsWith('error'));
  check('no errors in extension log (last run)', errs.length === 0, errs.join(' | '));

  // ---- 6. Popup + options pages render and work ----
  const extId = new URL(sw.url()).host;
  const pageErrors = [];
  const popup = await ctx.newPage();
  popup.on('pageerror', (e) => pageErrors.push('popup: ' + e.message));
  await popup.goto(`chrome-extension://${extId}/popup/popup.html`);
  await sleep(1500);
  const pop = await popup.evaluate(() => ({ phase: document.getElementById('phase').textContent, cd: document.getElementById('cd').textContent, log: document.getElementById('log').textContent.length, info: document.getElementById('runInfo').textContent }));
  check('P1: popup renders state, countdown and log', /stopped|idle/.test(pop.phase) && /\d\d:\d\d:\d\d/.test(pop.cd) && pop.log > 0, JSON.stringify(pop).slice(0, 200));
  const opt = await ctx.newPage();
  opt.on('pageerror', (e) => pageErrors.push('options: ' + e.message));
  await opt.goto(`chrome-extension://${extId}/options/options.html`);
  await sleep(800);
  await opt.click('#addItem');
  const last = opt.locator('#items .item').last();
  await last.locator('[data-f="include"]').fill('nuptse, 1996');
  await last.locator('[data-f="sizes"]').fill('M, L');
  await last.locator('[data-f="site"]').selectOption('tnf');
  await opt.locator('[data-p="email"]').fill('saved@example.com');
  await opt.click('#save');
  await sleep(500);
  const saved = await sw.evaluate(() => chrome.storage.local.get(['watchlist', 'profiles']));
  const lastItem = saved.watchlist[saved.watchlist.length - 1];
  check('O1: options page saves watchlist item + profile (card kept)', lastItem.site === 'tnf' && lastItem.include.join('|') === 'nuptse|1996' && lastItem.sizes.join('|') === 'M|L' && saved.profiles[0].shipping.email === 'saved@example.com' && saved.profiles[0].card && saved.profiles[0].card.last4 === '4242', JSON.stringify(lastItem));
  check('P2: no JS errors on popup/options', pageErrors.length === 0, pageErrors.join(' | '));

  await ctx.close();
  const failed = results.filter((x) => !x.ok);
  console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
  process.exit(failed.length ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(2); });
