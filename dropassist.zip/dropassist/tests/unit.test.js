// Run: node --test tests/
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../lib/ns.js');
const time = require('../lib/time.js');
const M = require('../lib/match.js');

const NY = 'America/New_York';
const iso = (ms) => new Date(ms).toISOString();

test('next Thursday 11:00 New York during EST (UTC-5)', () => {
  const now = Date.parse('2026-11-25T23:10:00Z'); // Wed 6:10 PM ET
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY })), '2026-11-26T16:00:00.000Z');
});

test('next Thursday 11:00 New York during EDT (UTC-4)', () => {
  const now = Date.parse('2026-07-06T12:00:00Z'); // Mon
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY })), '2026-07-09T15:00:00.000Z');
});

test('Thursday after 11:00 rolls to next week, unless inside grace window', () => {
  const now = Date.parse('2026-11-26T16:03:00Z'); // Thu 11:03 ET
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY })), '2026-12-03T16:00:00.000Z');
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY, graceMs: 10 * 60000 })), '2026-11-26T16:00:00.000Z');
});

test('Thursday just before 11:00 is today', () => {
  const now = Date.parse('2026-11-26T15:59:30Z');
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY })), '2026-11-26T16:00:00.000Z');
});

test('DST switch week (Nov 1 2026 falls back) resolves correctly', () => {
  const now = Date.parse('2026-10-30T12:00:00Z'); // Fri before fall-back
  assert.equal(iso(time.nextWeeklyDrop(now, { timeZone: NY })), '2026-11-05T16:00:00.000Z');
});

test('zonedToEpoch round-trips', () => {
  const t = time.zonedToEpoch(2026, 3, 12, 11, 0, NY); // after spring-forward (Mar 8 2026)
  assert.equal(iso(t), '2026-03-12T15:00:00.000Z');
});

test('formatCountdown', () => {
  assert.equal(time.formatCountdown(3723400), '01:02:03.4');
  assert.equal(time.formatCountdown(90061000), '1d 01:01:01.0');
  assert.equal(time.formatCountdown(-1500), '-00:00:01.5');
});

test('sizeKey aliases', () => {
  assert.equal(M.sizeKey('Medium'), 'm');
  assert.equal(M.sizeKey('M'), 'm');
  assert.equal(M.sizeKey('XLarge'), 'xl');
  assert.equal(M.sizeKey('X-Large'), 'xl');
  assert.equal(M.sizeKey('XXLarge'), 'xxl');
  assert.equal(M.sizeKey('2XL'), 'xxl');
  assert.equal(M.sizeKey('US 10.5'), '10.5');
  assert.equal(M.sizeKey('N/A'), 'os');
});

test('keywords are whole-word: "tee" does not match "steel"', () => {
  assert.equal(M.hasTerm(M.norm('Steel Toe Boot'), 'tee'), false);
  assert.equal(M.hasTerm(M.norm('Box Logo Tee'), 'tee'), true);
  assert.equal(M.hasTerm(M.norm('Supreme®/Dickies® Leather Hooded Work Jacket'), 'dickies'), true);
  assert.equal(M.hasTerm(M.norm('Box Logo Hooded Sweatshirt'), 'box logo'), true);
});

const coat = (id, color, sizes) => ({
  id, title: 'Supreme®/Schott® Hooded Shearling Coat', color, style: 'J109', url: `/products/h${id}`, handle: `h${id}`,
  variants: Object.entries(sizes).map(([t, a], i) => ({ id: Number(id) * 10 + i, title: t, available: a }))
});

test('evaluate: include/exclude/color/size priority', () => {
  const item = { id: 'a', include: ['shearling', 'coat'], exclude: ['vest'], colors: ['black', 'tan'], sizes: ['L', 'M'] };
  const p = coat('1', 'Tan', { Small: true, Medium: true, Large: false });
  const r = M.evaluate(p, item, {});
  assert.equal(r.ok, true);
  assert.equal(r.variant.title, 'Medium');
  assert.equal(r.colorRank, 1);
  assert.equal(M.evaluate(coat('2', 'Red', { Large: true }), item, {}).reason, 'color "Red" not in your list');
  assert.match(M.evaluate(coat('3', 'Black', { Small: true, XLarge: true }), item, {}).reason, /sold out in your sizes/);
  assert.equal(M.evaluate(coat('4', 'Black', { Small: false }), item, {}).reason, 'sold out');
});

test('colors list ending in "any" accepts anything as last resort', () => {
  const item = { id: 'a', include: ['coat'], colors: ['black', 'any'], sizes: [] };
  assert.equal(M.evaluate(coat('1', 'Red', { M: true, L: true }), item, {}).colorRank, 1);
});

test('old-stock filter uses baseline for keyword items only', () => {
  const p = coat('9', 'Black', { L: true });
  const kw = { id: 'k', include: ['coat'] };
  const byUrl = { id: 'u', url: 'https://us.supreme.com/products/h9' };
  assert.equal(M.evaluate(p, kw, { onlyNew: true, baseline: ['9'] }).ok, false);
  assert.equal(M.evaluate(p, byUrl, { onlyNew: true, baseline: ['9'] }).ok, true);
});

test('planPicks: best color wins, a product is never picked twice, done items skipped', () => {
  const products = [coat('1', 'Tan', { L: true }), coat('2', 'Black', { L: true })];
  const items = [
    { id: 'first', include: ['coat'], colors: ['black', 'tan'], sizes: ['L'] },
    { id: 'second', include: ['coat'], colors: ['black', 'tan'], sizes: ['L'] },
    { id: 'done', include: ['coat'] }
  ];
  const { picks } = M.planPicks(products, items, { doneItemIds: ['done'] });
  assert.equal(picks.length, 2);
  assert.equal(picks[0].itemId, 'first');
  assert.equal(picks[0].color, 'Black');
  assert.equal(picks[1].color, 'Tan');
});

test('planPicks: TNF products without variants are deferred to the product page', () => {
  const products = [{ id: '/en-us/p/x/mens-nuptse-NF0A3C8D', title: 'Men’s 1996 Retro Nuptse Jacket', color: '', url: '/en-us/p/x/mens-nuptse-NF0A3C8D?color=JK3', variants: null }];
  const { picks } = M.planPicks(products, [{ id: 'n', include: ['nuptse'], sizes: ['M'] }], {});
  assert.equal(picks.length, 1);
  assert.equal(picks[0].needsPage, true);
  assert.equal(picks[0].variantId, null);
});

test('match-anything items only log hits', () => {
  const products = [coat('1', 'Tan', { L: false }), coat('2', 'Black', { L: true })];
  const { picks, decisions } = M.planPicks(products, [{ id: 'dry', include: [] }], {});
  assert.equal(picks[0].productId, '2');
  assert.equal(decisions.length, 1);
});

const V = require('../lib/vault.js');

test('card normalize + Luhn', () => {
  const c = V.normalizeCard({ number: '4242 4242 4242 4242', exp: '8/2029', cvv: '123', name: ' Gavin ' });
  assert.deepEqual(c, { number: '4242424242424242', mm: '08', yy: '29', cvv: '123', name: 'Gavin' });
  assert.throws(() => V.normalizeCard({ number: '4242 4242 4242 4241', exp: '08/29' }), /checksum/);
  assert.throws(() => V.normalizeCard({ number: '4242424242424242', exp: '13/29' }), /Expiry/);
  assert.equal(V.cardBrand('5555555555554444'), 'Mastercard');
  assert.equal(V.cardBrand('378282246310005'), 'Amex');
});

test('vault: encrypt/decrypt round trip, wrong passphrase rejected, ciphertext has no card digits', async () => {
  const { meta, key } = await V.create('correct horse');
  const box = await V.encryptJSON(key, { number: '4242424242424242' });
  assert.ok(!JSON.stringify(box).includes('4242424242424242'));
  const k2 = await V.unlock(meta, 'correct horse');
  assert.equal((await V.decryptJSON(k2, box)).number, '4242424242424242');
  await assert.rejects(V.unlock(meta, 'wrong pass'), /Wrong passphrase/);
  const k3 = await V.importKey(await V.exportKey(key));
  assert.equal((await V.decryptJSON(k3, box)).number, '4242424242424242');
});
