// The North Face adapter. Same interface as adapters/supreme.js.
// TNF has no direct cart call here: its cart API sits behind bot protection, so we click the real button,
// verify the cart count went up, and hand over to you if it didn't.
(function (root) {
  'use strict';
  const DA = root.DA;
  const cfg = DA.config.tnf;
  const S = cfg.selectors;

  function pageType(loc) {
    const p = loc.pathname;
    if (cfg.blockers.queueUrl.test(p)) return 'queue';
    if (/\/checkout/i.test(p)) return 'checkout';
    if (/\/cart\/?$/i.test(p)) return 'cart';
    if (/\/p\//.test(p)) return 'product';
    if (/\/c\//.test(p)) return 'listing';
    return 'other';
  }

  // URL items are "found" right away (stock is checked on the product page by reloading it).
  // Keyword items search the listing pages' product cards by title.
  async function findProducts(ctx) {
    const items = (ctx && ctx.items) || [];
    const products = [];
    for (const it of items) {
      if (it.url) products.push({ id: DA.match.urlPath(it.url), title: it.label || it.url, color: '', url: it.url, variants: null });
    }
    const kwItems = items.filter((it) => !it.url);
    if (!kwItems.length) return { status: 200, products };

    const cats = [...new Set(kwItems.flatMap((it) => (it.category ? [it.category] : cfg.defaultCategories)))];
    let lastBad = 0;
    for (const c of cats) {
      let r;
      try { r = await fetch(c, { cache: 'no-store', credentials: 'same-origin', headers: { Accept: 'text/html' } }); } catch (e) { return { status: 0, error: e.message }; }
      if (!r.ok) { lastBad = r.status; continue; }
      const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
      for (const a of doc.querySelectorAll(S.productCardTitle)) {
        const href = a.getAttribute('href');
        if (!href) continue;
        const id = DA.match.urlPath(href);
        if (products.some((p) => p.id === id)) continue;
        products.push({ id, title: a.textContent.replace(/\s+/g, ' ').trim(), color: '', url: href, variants: null });
      }
    }
    if (lastBad && products.length === 0) return { status: lastBad };
    return { status: 200, products };
  }

  function colorName(btn) {
    const sr = btn.querySelector('.sr-only');
    return ((sr && sr.textContent) || btn.getAttribute('aria-label') || '').trim();
  }

  function readSizes() {
    return [...document.querySelectorAll(S.sizeLabel)].map((label) => {
      const input = label.querySelector('input');
      return {
        label, input,
        value: input ? input.value : label.textContent.trim(),
        available: !!label.querySelector(S.sizeAvailable) && !(input && input.disabled)
      };
    });
  }

  async function selectVariant(pick, item) {
    const ready = await DA.waitFor(() => document.querySelector(S.sizeLabel) || document.querySelector(S.addToCart), 10000);
    if (!ready) return { ok: false, retry: true, reason: 'product page not live yet (no sizes / Add to Cart)' };

    // Color, by your priority
    let colorPicked = '';
    const wantColors = DA.match.list(item && item.colors);
    const buttons = [...document.querySelectorAll(S.colorButton)];
    if (wantColors.length && buttons.length) {
      let best = null, bestRank = Infinity;
      for (const b of buttons) {
        if (b.querySelector('[unavailable="true"]')) continue;
        const rank = DA.match.colorRank(colorName(b), wantColors);
        if (rank >= 0 && rank < bestRank) { best = b; bestRank = rank; }
      }
      if (!best) return { ok: false, retry: true, reason: `none of your colors available (on page: ${buttons.map(colorName).join(', ')})` };
      colorPicked = colorName(best);
      if (best.getAttribute('aria-current') !== 'true') {
        best.click();
        await DA.sleep(900); // sizes re-render for the new color
      }
    } else {
      const cur = buttons.find((b) => b.getAttribute('aria-current') === 'true');
      if (cur) colorPicked = colorName(cur);
    }

    // Size, by your priority
    const sizes = readSizes();
    if (!sizes.length) return { ok: true, size: 'one size', color: colorPicked };
    const avail = sizes.filter((s) => s.available);
    const want = DA.match.list(item && item.sizes);
    let chosen = null;
    if (!want.length) chosen = avail[0] || null;
    for (const s of want) {
      chosen = (s === '*' || DA.match.norm(s) === 'any') ? avail[0] : avail.find((a) => DA.match.sizeKey(a.value) === DA.match.sizeKey(s));
      if (chosen) break;
    }
    if (!chosen) {
      return { ok: false, retry: true, reason: avail.length ? `your sizes are sold out (in stock: ${avail.map((a) => a.value).join(', ')})` : 'no sizes in stock yet' };
    }
    if (!(chosen.input && chosen.input.checked)) { chosen.label.click(); await DA.sleep(300); }
    return { ok: true, size: chosen.value, color: colorPicked };
  }

  function cartCount() {
    const a = document.querySelector(S.cartLink);
    const m = a && a.textContent.match(/(\d+)\s*items?/i);
    return m ? Number(m[1]) : null;
  }

  async function clickAddToCart() {
    const btn = document.querySelector(S.addToCart);
    if (!btn) return { ok: false, retry: true, reason: 'Add to Cart button not found' };
    if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return { ok: false, retry: true, reason: 'Add to Cart is disabled (not live or sold out)' };
    const before = cartCount() || 0;
    btn.click();
    const ok = await DA.waitFor(() => (cartCount() || 0) > before, 7000, 150);
    return ok ? { ok: true } : { ok: false, manual: true, button: btn, reason: "the cart didn't update — the site's bot protection probably rejected the automated click" };
  }

  function goToCheckout() { location.assign(cfg.cartPath); }

  function findByText(selectorList, re) {
    const cands = [];
    for (const s of selectorList) cands.push(...document.querySelectorAll(s));
    cands.push(...document.querySelectorAll('button, a'));
    return cands.find((el) => DA.fill.isVisible(el) && re.test(el.textContent || '')) || null;
  }

  async function clickCheckoutOnCart() {
    const btn = await DA.waitFor(() => findByText(S.cartCheckoutButton, S.checkoutButtonText), 10000, 200);
    if (!btn) return false;
    btn.click();
    return true;
  }

  async function waitForCheckout() {
    return DA.waitFor(() => DA.fill.findField('email', cfg.checkoutFields[1], cfg.checkoutExclude) ||
      DA.fill.findField('firstName', cfg.checkoutFields[2], cfg.checkoutExclude), 15000, 250);
  }

  function findPayButton() {
    const cands = [];
    for (const s of S.payButton) cands.push(...document.querySelectorAll(s));
    return cands.find((el) => DA.fill.isVisible(el) && S.payButtonText.test(el.textContent || el.value || '')) || null;
  }

  function focusCard() {
    const f = document.querySelector(S.cardNumberFrame);
    if (f) { f.scrollIntoView({ block: 'center' }); try { f.focus(); } catch (_) { /* cross-origin */ } }
    return !!f;
  }

  // Baseline for the old-stock filter: what keyword searches already return before the drop.
  async function snapshot(ctx) {
    const kw = ((ctx && ctx.items) || []).filter((i) => !i.url);
    if (!kw.length) return [];
    const r = await findProducts({ items: kw });
    return r.products ? r.products.map((p) => p.id) : null;
  }

  DA.adapter = {
    cfg, pageType, findProducts, snapshot, selectVariant, clickAddToCart, cartCount,
    goToCheckout, clickCheckoutOnCart, waitForCheckout, findPayButton, focusCard,
    addToCart: null, clearCart: null,
    listingPath: null
  };
})(typeof self !== 'undefined' ? self : globalThis);
