// Service worker: owns the run state, alarms, clock sync, notifications and sound.
// MV3 workers sleep when idle, so everything important lives in chrome.storage.local and chrome.alarms;
// the content script in the run tab does the second-by-second work.
importScripts('lib/ns.js', 'lib/time.js', 'lib/match.js', 'lib/defaults.js', 'lib/vault.js');

const DA = self.DA;

const SITES = {
  supreme: { name: 'Supreme', origin: 'https://us.supreme.com', start: '/collections/new', clock: '/cart.js', match: 'https://us.supreme.com/*' },
  tnf: { name: 'The North Face', origin: 'https://www.thenorthface.com', start: '/en-us', clock: '/en-us', match: 'https://www.thenorthface.com/*' }
};
const LIVE_PHASES = ['scheduled', 'armed', 'monitoring', 'carting', 'manual', 'checkout', 'ready', 'paused'];
const MAX_LOG = 500;

// ---------------- storage ----------------
async function getSettings() { const { settings } = await chrome.storage.local.get('settings'); return DA.clampSettings(settings || {}); }
// Profiles: [{ id, name, shipping: {...}, card: { enc:{iv,ct}, last4, brand, exp } | null }], one active.
async function getProfiles() {
  const st = await chrome.storage.local.get(['profiles', 'activeProfileId', 'profile']);
  let profiles = Array.isArray(st.profiles) ? st.profiles : null;
  if (!profiles) { // migrate v1.0 single profile
    profiles = [{ id: 'p1', name: 'Main', shipping: Object.assign({}, DA.defaults.profile, st.profile || {}), card: null }];
    await chrome.storage.local.set({ profiles, activeProfileId: 'p1' });
  }
  const active = profiles.find((p) => p.id === st.activeProfileId) || profiles[0];
  return { profiles, active };
}
async function getProfile() { const { active } = await getProfiles(); return Object.assign({}, DA.defaults.profile, (active && active.shipping) || {}); }

// ---------------- card vault ----------------
async function vaultKey() {
  const { vaultKey: raw } = await chrome.storage.session.get('vaultKey');
  return raw ? DA.vault.importKey(raw) : null;
}
async function vaultStatus() {
  const [{ vaultMeta }, { vaultKey: raw }, { profiles, active }] = await Promise.all([chrome.storage.local.get('vaultMeta'), chrome.storage.session.get('vaultKey'), getProfiles()]);
  return {
    exists: !!vaultMeta, unlocked: !!raw, activeProfileId: active && active.id,
    profiles: profiles.map((p) => ({ id: p.id, name: p.name, card: p.card ? { brand: p.card.brand, last4: p.card.last4, exp: p.card.exp } : null }))
  };
}
const cardAllow = new Map(); // tabId -> expiry ms: a checkout page in this tab asked for card fill
const isCardFrameUrl = (u) => { try { const h = new URL(u).hostname; return h === 'checkout.pci.shopifyinc.com' || h.endsWith('.adyen.com'); } catch (_) { return false; } };
const isCheckoutUrl = (u) => { try { return !!siteFromUrl(u) && /\/checkout/i.test(new URL(u).pathname); } catch (_) { return false; } };
async function getWatchlist() { const { watchlist } = await chrome.storage.local.get('watchlist'); return Array.isArray(watchlist) ? watchlist : []; }
async function getRun() { const { run } = await chrome.storage.local.get('run'); return run || { active: false, phase: 'idle' }; }

let runChain = Promise.resolve();
function updateRun(mutate) {
  runChain = runChain.catch(() => {}).then(async () => {
    const r = await getRun();
    const next = (await mutate(r)) || r;
    await chrome.storage.local.set({ run: next });
    return next;
  });
  return runChain;
}

let logChain = Promise.resolve();
function L(msg, lvl = 'info', site = '') {
  const entry = { t: Date.now(), lvl, site, msg: String(msg) };
  console[lvl === 'error' ? 'error' : lvl === 'warn' ? 'warn' : 'log'](`[DropAssist] ${entry.msg}`);
  logChain = logChain.catch(() => {}).then(async () => {
    const { log = [] } = await chrome.storage.local.get('log');
    log.push(entry);
    if (log.length > MAX_LOG) log.splice(0, log.length - MAX_LOG);
    await chrome.storage.local.set({ log });
  });
  return logChain;
}

function siteFromUrl(url) {
  try {
    const h = new URL(url).hostname;
    if (h === 'us.supreme.com') return 'supreme';
    if (h === 'www.thenorthface.com') return 'tnf';
  } catch (_) { /* ignore */ }
  return null;
}
function absUrl(site, u) { try { return new URL(u, SITES[site].origin).href; } catch (_) { return SITES[site].origin; } }

// ---------------- clock ----------------
// Server Date headers have 1-second resolution, so we watch for the second to tick over between two
// requests; that pins the server clock to roughly ±(gap/2). Falls back to a single mid-second estimate.
async function syncClock(siteId) {
  const site = SITES[siteId];
  const sample = async () => {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 3000);
    const t0 = Date.now();
    let res;
    try { res = await fetch(site.origin + site.clock, { method: 'HEAD', cache: 'no-store', credentials: 'include', signal: ctl.signal }); }
    finally { clearTimeout(timer); }
    const t1 = Date.now();
    const d = Date.parse(res.headers.get('date') || '');
    if (!isFinite(d)) throw new Error('no Date header');
    return { d, mid: (t0 + t1) / 2, rtt: t1 - t0 };
  };
  let prev = null, fallback = null, result = null, failures = 0;
  for (let i = 0; i < 14 && !result && failures < 3; i++) {
    let cur;
    try { cur = await sample(); } catch (e) { failures++; continue; }
    if (!fallback || cur.rtt < fallback.rtt) fallback = cur;
    if (prev && cur.d > prev.d) {
      const boundaryLocal = (prev.mid + cur.mid) / 2;
      result = { offsetMs: Math.round(cur.d - boundaryLocal), accuracyMs: Math.round((cur.mid - prev.mid) / 2 + cur.rtt / 2) };
    }
    prev = cur;
    await DA.sleep(110);
  }
  if (!result && fallback) result = { offsetMs: Math.round(fallback.d + 500 - fallback.mid), accuracyMs: 500 + Math.round(fallback.rtt / 2) };
  if (!result) throw new Error(`Couldn't reach ${site.name} to sync the clock`);
  const clock = Object.assign({ site: siteId, at: Date.now() }, result);
  await chrome.storage.local.set({ clock });
  return clock;
}

// ---------------- alerts ----------------
async function playSound(kind) {
  const s = await getSettings();
  if (!s.sound) return;
  try {
    if (chrome.offscreen && chrome.offscreen.createDocument) {
      let exists = false;
      if (chrome.runtime.getContexts) exists = (await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] })).length > 0;
      if (!exists) {
        await chrome.offscreen.createDocument({ url: 'offscreen/offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'Alert sound when checkout is ready' })
          .catch((e) => { if (!/single offscreen|already/i.test(String(e))) throw e; });
      }
      await chrome.runtime.sendMessage({ target: 'offscreen', type: 'beep', kind });
      return;
    }
  } catch (e) { console.warn('[DropAssist] offscreen audio unavailable, using page audio', e); }
  const r = await getRun();
  if (r.tabId) chrome.tabs.sendMessage(r.tabId, { type: 'beep', kind }).catch(() => {});
}

async function focusRunTab() {
  const r = await getRun();
  if (!r.tabId) return;
  try {
    const tab = await chrome.tabs.update(r.tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true, drawAttention: true });
  } catch (_) { /* tab gone */ }
}

async function alertUser(title, message, kind) {
  try {
    await chrome.notifications.create('da-' + Date.now(), {
      type: 'basic', iconUrl: 'icons/icon128.png', title, message, priority: 2,
      requireInteraction: kind === 'ready' || kind === 'manual'
    });
  } catch (e) { console.warn('[DropAssist] notification failed', e); }
  await playSound(kind === 'ready' ? 'ready' : 'warn');
  if (kind === 'ready' || kind === 'manual' || kind === 'blocked') await focusRunTab();
}

chrome.notifications.onClicked.addListener((id) => { focusRunTab(); chrome.notifications.clear(id); });

// ---------------- run control ----------------
function itemDropAt(item, settings, now) {
  if (item.dropAt) return Number(item.dropAt);
  return DA.time.nextWeeklyDrop(now, {
    weekday: settings.dropWeekday, hour: settings.dropHour, minute: settings.dropMinute,
    timeZone: settings.dropTz, graceMs: settings.runMin * 60000
  });
}

async function arm({ mode, site, keyword }) {
  const [settings, watchlist, profile] = await Promise.all([getSettings(), getWatchlist(), getProfile()]);
  const now = Date.now();
  let items, dropAt, chosen;

  if (mode === 'dry') {
    chosen = site || 'supreme';
    const template = watchlist.find((i) => i.enabled && i.site === chosen) || {};
    const kw = String(keyword || '').trim();
    const isUrl = /^https?:\/\//i.test(kw);
    items = [{
      id: 'dry-' + DA.uid(), enabled: true, site: chosen, label: 'Dry run' + (kw ? `: ${kw}` : ''),
      include: kw && !isUrl ? [kw] : [], exclude: [], colors: [], sizes: template.sizes || [],
      url: isUrl ? kw : '', category: '', dropAt: null
    }];
    dropAt = now;
  } else {
    const enabled = watchlist.filter((i) => i.enabled);
    if (!enabled.length) throw new Error('Your watchlist has no enabled items — add one in Options.');
    if (mode === 'now') {
      chosen = site || enabled[0].site;
      items = enabled.filter((i) => i.site === chosen);
      if (!items.length) throw new Error(`No enabled ${SITES[chosen].name} items in your watchlist.`);
      dropAt = now;
    } else {
      const grace = settings.runMin * 60000;
      const timed = enabled.map((i) => ({ i, t: itemDropAt(i, settings, now) }))
        .filter((x) => x.t > now - grace).sort((a, b) => a.t - b.t);
      if (!timed.length) throw new Error('No upcoming drop: every custom drop time is in the past.');
      dropAt = timed[0].t;
      chosen = timed[0].i.site;
      items = timed.filter((x) => x.i.site === chosen && Math.abs(x.t - dropAt) <= 5 * 60000).map((x) => x.i);
      const other = enabled.length - items.length;
      if (other) L(`${other} watchlist item(s) are for a different site or drop time and aren't in this run`);
    }
  }

  let clock = null;
  try { clock = await syncClock(chosen); } catch (e) { L(`Clock sync failed (${e.message}); using your computer's clock`, 'warn', chosen); }
  const offsetMs = clock ? clock.offsetMs : 0;
  const leadMs = mode === 'scheduled' ? settings.leadSec * 1000 : 0;
  const startAt = mode === 'scheduled' ? dropAt - leadMs : now + offsetMs;

  const run = {
    active: true, id: DA.uid(), mode, dryRun: mode === 'dry', site: chosen, items,
    dropAt: mode === 'scheduled' ? dropAt : now + offsetMs,
    startAt, stopAt: (mode === 'scheduled' ? dropAt : now + offsetMs) + settings.runMin * 60000,
    onlyNew: mode === 'scheduled' && settings.onlyNew,
    phase: 'scheduled', tabId: null, offsetMs, baseline: null,
    picks: [], carted: [], doneItemIds: [], marks: {}, blocked: null, note: '', resumePhase: null
  };
  await chrome.storage.local.set({ run });
  await chrome.alarms.clearAll();

  const names = items.map((i) => i.label || [DA.match.list(i.include).join(' + '), i.url].filter(Boolean).join(' ') || 'any item').join('; ');
  if (mode === 'scheduled') {
    L(`Armed for ${SITES[chosen].name} drop at ${DA.time.formatInZone(dropAt, settings.dropTz)} (${new Date(dropAt).toLocaleString()} your time). Items: ${names}`, 'ok', chosen);
  } else {
    L(`${mode === 'dry' ? 'Dry run' : 'Live run'} started on ${SITES[chosen].name}. Items: ${names}`, 'ok', chosen);
  }
  if (!profile.email && !profile.address1) L('Checkout profile is empty — fill it in Options or checkout won\'t be autofilled', 'warn');
  const vs = await vaultStatus();
  const ap = vs.profiles.find((p) => p.id === vs.activeProfileId);
  if (ap && ap.card && !vs.unlocked) L(`Card vault is locked — ${ap.card.brand} •${ap.card.last4} won't be filled. Unlock it in the popup.`, 'warn');

  const wakeLocal = startAt - offsetMs - 60000;
  if (Date.now() >= wakeLocal) await wake();
  else chrome.alarms.create('da-wake', { when: wakeLocal });
  chrome.alarms.create('da-stop', { when: run.stopAt - offsetMs + 2000 });
  return getRun();
}

// ~60 s before monitoring: re-sync the clock, open/focus the site tab, hand control to the content script.
async function wake() {
  const r0 = await getRun();
  if (!r0.active) return;
  try {
    const clock = await syncClock(r0.site);
    await updateRun((r) => { r.offsetMs = clock.offsetMs; return r; });
    L(`Clock synced with ${SITES[r0.site].name}: offset ${clock.offsetMs >= 0 ? '+' : ''}${clock.offsetMs} ms (±${clock.accuracyMs} ms)`, 'info', r0.site);
  } catch (e) { L(`Clock re-sync failed: ${e.message}`, 'warn', r0.site); }
  await updateRun((r) => { if (r.phase === 'scheduled') r.phase = 'armed'; return r; });
  await openRunTab();
}

async function openRunTab() {
  const r = await getRun();
  const site = SITES[r.site];
  let url = site.origin + site.start;
  const urlItem = (r.items || []).find((i) => i.url);
  if (r.site === 'tnf' && urlItem && (r.items || []).length === 1) url = absUrl('tnf', urlItem.url);

  let tab = null;
  if (r.tabId) tab = await chrome.tabs.get(r.tabId).catch(() => null);
  if (!tab) {
    const tabs = await chrome.tabs.query({ url: site.match });
    tab = tabs.find((t) => t.active) || tabs[0] || null;
  }
  if (tab) tab = await chrome.tabs.update(tab.id, { active: true, url });
  else {
    try { tab = await chrome.tabs.create({ url, active: true }); }
    catch (_) { // no browser window open (e.g. browser running in the background)
      const win = await chrome.windows.create({ url, focused: true });
      tab = win.tabs[0];
    }
  }
  await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  await updateRun((x) => { x.tabId = tab.id; return x; });
}

async function stopRun(reason, lvl = 'info') {
  const r = await updateRun((x) => { x.active = false; x.phase = 'stopped'; x.note = reason; return x; });
  await chrome.alarms.clearAll();
  L(reason, lvl, r.site || '');
  if (r.tabId) chrome.tabs.sendMessage(r.tabId, { type: 'runChanged' }).catch(() => {});
  return r;
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === 'da-wake') await wake();
  if (a.name === 'da-stop') {
    const r = await getRun();
    if (r.active && ['scheduled', 'armed', 'monitoring', 'paused'].includes(r.phase)) {
      await stopRun('Monitoring window ended with no match', 'warn');
      await alertUser('DropAssist: window closed', 'Nothing on your watchlist matched during the drop window.', 'info');
    }
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const r = await getRun();
  if (r.active && r.tabId === tabId) {
    await updateRun((x) => { x.tabId = null; return x; });
    L('The run tab was closed. Open the site again and the run continues in that tab.', 'warn', r.site);
  }
});

// ---------------- messages ----------------
async function handle(msg, sender) {
  const tabId = sender.tab && sender.tab.id;
  switch (msg.type) {
    case 'hello': {
      const [settings, profile] = await Promise.all([getSettings(), getProfile()]);
      let r = await getRun();
      const site = siteFromUrl(msg.url || (sender.tab && sender.tab.url) || '');
      if (tabId && r.active && !r.tabId && site === r.site && r.phase !== 'scheduled') {
        r = await updateRun((x) => { x.tabId = tabId; return x; });
        L('Run continues in this tab', 'info', site);
      }
      return { isRunTab: !!(tabId && r.active && r.tabId === tabId), run: r, settings, profile, items: r.items || [] };
    }
    case 'log':
      await L(msg.msg, msg.lvl, msg.site || siteFromUrl(sender.url || '') || '');
      return { ok: true };
    case 'mark': {
      const r = await updateRun((x) => { x.marks = x.marks || {}; if (!x.marks[msg.name]) x.marks[msg.name] = Date.now(); return x; });
      return { run: r };
    }
    case 'phase': {
      const prev = await getRun();
      if (!prev.active) return { run: prev };
      const r = await updateRun((x) => {
        Object.assign(x, msg.patch || {});
        x.phase = msg.phase;
        if (msg.note) x.note = msg.note;
        x.marks = x.marks || {};
        if (msg.phase === 'monitoring' && !x.marks.monitor) x.marks.monitor = Date.now();
        if (msg.phase === 'stopped') x.active = false;
        return x;
      });
      if (msg.note) await L(msg.note, msg.lvl || 'info', r.site);
      if (msg.phase !== prev.phase) await onPhaseChange(prev, r);
      return { run: r };
    }
    case 'blocked': {
      const prev = await getRun();
      if (!prev.active || prev.blocked === msg.kind) return { ok: true };
      await updateRun((x) => { x.blocked = msg.kind; return x; });
      L(`${msg.kind === 'captcha' ? 'CAPTCHA' : 'Queue / waiting room'} on ${msg.url || 'page'} — paused until it clears`, 'warn', prev.site);
      await alertUser(msg.kind === 'captcha' ? 'DropAssist: CAPTCHA' : 'DropAssist: in the queue',
        msg.kind === 'captcha' ? 'Solve the CAPTCHA — automation resumes after.' : 'Waiting room — automation resumes when you get through.', 'blocked');
      return { ok: true };
    }
    case 'unblocked': {
      const r = await updateRun((x) => { x.blocked = null; return x; });
      L('Cleared — resuming', 'ok', r.site);
      return { ok: true };
    }
    case 'stopRun':
      return { run: await stopRun(msg.reason || 'Stopped') };
    case 'resume': {
      const r = await updateRun((x) => { if (x.phase === 'paused') { x.phase = x.resumePhase || 'monitoring'; x.resumePhase = null; x.active = true; } return x; });
      L('Resumed', 'info', r.site);
      if (r.tabId) chrome.tabs.sendMessage(r.tabId, { type: 'runChanged' }).catch(() => {});
      else if (r.active) await openRunTab();
      return { run: r };
    }

    // ---- card fill ----
    case 'requestCardFill': { // from the checkout page (top frame) right after it fills shipping
      if (!tabId || sender.frameId !== 0 || !isCheckoutUrl(sender.url || '')) return { ok: false, reason: 'not a checkout page' };
      const { active } = await getProfiles();
      if (!active || !active.card) return { ok: false, reason: 'no card saved on the active profile' };
      if (!(await vaultKey())) return { ok: false, reason: 'card vault is locked — unlock it in the popup' };
      cardAllow.set(tabId, Date.now() + 120000);
      chrome.tabs.sendMessage(tabId, { type: 'cardFillNow' }).catch(() => {}); // reaches every frame in the tab
      return { ok: true, card: `${active.card.brand} •${active.card.last4}` };
    }
    case 'cardField': { // from a payment iframe inside that checkout tab
      if (!tabId || sender.frameId === 0 || !isCardFrameUrl(sender.url || '')) return { value: null };
      if (!isCheckoutUrl((sender.tab && sender.tab.url) || '') || !((cardAllow.get(tabId) || 0) > Date.now())) return { value: null };
      const key = await vaultKey();
      const { active } = await getProfiles();
      if (!key || !active || !active.card) return { value: null };
      const c = await DA.vault.decryptJSON(key, active.card.enc);
      const fullName = [active.shipping.firstName, active.shipping.lastName].filter(Boolean).join(' ');
      const value = { number: c.number, exp: `${c.mm} / ${c.yy}`, cvv: c.cvv, name: c.name || fullName }[msg.field];
      return { value: value == null ? null : value };
    }
    case 'vaultStatus':
      return vaultStatus();
    case 'vaultCreate': {
      const { vaultMeta } = await chrome.storage.local.get('vaultMeta');
      if (vaultMeta) throw new Error('A vault already exists — unlock it instead');
      const { meta, key } = await DA.vault.create(msg.pass);
      await chrome.storage.local.set({ vaultMeta: meta });
      await chrome.storage.session.set({ vaultKey: await DA.vault.exportKey(key) });
      L('Card vault created and unlocked', 'ok');
      return vaultStatus();
    }
    case 'vaultUnlock': {
      const { vaultMeta } = await chrome.storage.local.get('vaultMeta');
      if (!vaultMeta) throw new Error('No vault yet — add a card in Options first');
      const key = await DA.vault.unlock(vaultMeta, msg.pass);
      await chrome.storage.session.set({ vaultKey: await DA.vault.exportKey(key) });
      L('Card vault unlocked until the browser closes', 'ok');
      return vaultStatus();
    }
    case 'vaultLock':
      await chrome.storage.session.remove('vaultKey');
      return vaultStatus();
    case 'vaultReset': { // forgot passphrase: wipes every saved card, keeps shipping
      const { profiles } = await getProfiles();
      for (const p of profiles) p.card = null;
      await chrome.storage.local.set({ profiles });
      await chrome.storage.local.remove('vaultMeta');
      await chrome.storage.session.remove('vaultKey');
      L('Card vault reset — all saved cards deleted', 'warn');
      return vaultStatus();
    }
    case 'saveCard': {
      const key = await vaultKey();
      if (!key) throw new Error('Unlock the card vault first');
      const card = DA.vault.normalizeCard(msg.card);
      const { profiles } = await getProfiles();
      const p = profiles.find((x) => x.id === msg.profileId);
      if (!p) throw new Error('Profile not found — save the profile first');
      p.card = { enc: await DA.vault.encryptJSON(key, card), last4: card.number.slice(-4), brand: DA.vault.cardBrand(card.number), exp: `${card.mm}/${card.yy}` };
      await chrome.storage.local.set({ profiles });
      return { card: { brand: p.card.brand, last4: p.card.last4, exp: p.card.exp } };
    }
    case 'removeCard': {
      const { profiles } = await getProfiles();
      const p = profiles.find((x) => x.id === msg.profileId);
      if (p) p.card = null;
      await chrome.storage.local.set({ profiles });
      return { ok: true };
    }
    case 'setActiveProfile':
      await chrome.storage.local.set({ activeProfileId: msg.id });
      return vaultStatus();

    // ---- popup / options ----
    case 'getState': {
      const [run, settings, watchlist, profile, store] = await Promise.all([getRun(), getSettings(), getWatchlist(), getProfile(), chrome.storage.local.get(['log', 'clock'])]);
      const now = Date.now();
      const enabled = watchlist.filter((i) => i.enabled);
      const next = { supreme: null, tnf: null };
      for (const i of enabled) {
        const t = itemDropAt(i, settings, now);
        if (t > now - settings.runMin * 60000 && (!next[i.site] || t < next[i.site])) next[i.site] = t;
      }
      const weekly = DA.time.nextWeeklyDrop(now, { weekday: settings.dropWeekday, hour: settings.dropHour, minute: settings.dropMinute, timeZone: settings.dropTz });
      return {
        run, settings, enabledCount: enabled.length, sitesEnabled: [...new Set(enabled.map((i) => i.site))],
        profileSet: !!(profile.email && profile.address1), next, weekly,
        clock: store.clock || null, log: (store.log || []).slice(-200), vault: await vaultStatus()
      };
    }
    case 'arm':
      return { run: await arm(msg) };
    case 'syncClock':
      return { clock: await syncClock(msg.site || 'supreme') };
    case 'clearLog':
      await chrome.storage.local.set({ log: [] });
      return { ok: true };
    case 'testSound':
      await playSound(msg.kind || 'ready');
      return { ok: true };
    case 'fillActiveTab': {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (!tab || !siteFromUrl(tab.url || '')) return { error: 'Open the Supreme or The North Face checkout page in the current tab first.' };
      try { return await chrome.tabs.sendMessage(tab.id, { type: 'fillNow' }); }
      catch (_) { return { error: 'The page isn\'t ready (or was open before the extension loaded) — reload it and try again.' }; }
    }
    default:
      return { error: 'unknown message ' + msg.type };
  }
}

async function onPhaseChange(prev, r) {
  if (r.phase === 'ready') {
    await alertUser(r.dryRun ? 'DropAssist: dry run reached checkout' : 'DropAssist: READY — click pay',
      r.dryRun ? 'Nothing was submitted. Clear the cart when done.' : (r.carted || []).map((c) => `${c.title} ${c.size}`).join(', ') || 'Checkout is filled.', 'ready');
  } else if (r.phase === 'manual') {
    await alertUser('DropAssist: your turn', 'Click Add to Cart on the highlighted button — the site rejected the automated click.', 'manual');
  } else if (r.phase === 'paused') {
    await alertUser('DropAssist: paused', r.note || 'Paused.', 'blocked');
  } else if (r.phase === 'stopped' && prev.phase !== 'stopped') {
    await chrome.alarms.clearAll();
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'offscreen') return false;
  handle(msg, sender).then(
    (res) => sendResponse(res),
    (e) => { L(`Error: ${e && e.message || e}`, 'error'); sendResponse({ error: String((e && e.message) || e) }); }
  );
  return true;
});

// ---------------- lifecycle ----------------
chrome.runtime.onInstalled.addListener(async (details) => {
  const cur = await chrome.storage.local.get(['settings', 'profile', 'watchlist']);
  const patch = {};
  if (!cur.settings) patch.settings = DA.defaults.settings;
  if (!cur.watchlist) patch.watchlist = DA.defaults.watchlist;
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
});

// After a browser restart: drop stale runs, re-create alarms for live ones.
async function restore() {
  const r = await getRun();
  if (!r.active) return;
  const now = Date.now() + (r.offsetMs || 0);
  if (now > r.stopAt && LIVE_PHASES.slice(0, 4).includes(r.phase)) { await stopRun('Run expired while the browser was closed', 'warn'); return; }
  const alarms = await chrome.alarms.getAll();
  if (!alarms.some((a) => a.name === 'da-stop')) chrome.alarms.create('da-stop', { when: r.stopAt - (r.offsetMs || 0) + 2000 });
  if (r.phase === 'scheduled' && !alarms.some((a) => a.name === 'da-wake')) {
    const wakeLocal = r.startAt - (r.offsetMs || 0) - 60000;
    if (Date.now() >= wakeLocal) await wake(); else chrome.alarms.create('da-wake', { when: wakeLocal });
  }
}
chrome.runtime.onStartup.addListener(restore);
